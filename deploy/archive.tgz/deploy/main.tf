terraform {
  required_providers {
    ibm = {
      source  = "IBM-Cloud/ibm"
      version = ">= 1.59.0"
    }
  }
}

provider "ibm" {
  region = "us-east"
}

variable "ibm_api_key" {
  default = "MKZMaick3qLhWNEEvoqYpt5F5G4o94vUJ5HKwrrjqJ2v"
}

variable "project_name" { default = "dataclenz" }

variable "backend_image" {
  default = "icr.io/dataclenz/backend:latest"
}

variable "frontend_image" {
  default = "icr.io/dataclenz/frontend:latest"
}

variable "registry_secret_name" {
  default = "icr-secret"
}

resource "ibm_code_engine_secret" "registry_secret" {
  project_id = ibm_code_engine_project.dataclenz.project_id
  name       = var.registry_secret_name
  format     = "registry"
  
  data = {
    "username" = "iamapikey"
    "password" = var.ibm_api_key
    "server"   = "icr.io"
  }
}

resource "ibm_code_engine_project" "dataclenz" {
  name = var.project_name
}

resource "ibm_code_engine_app" "backend" {
  name            = "backend"
  project_id      = ibm_code_engine_project.dataclenz.project_id
  image_reference = var.backend_image
  image_secret    = ibm_code_engine_secret.registry_secret.name
  image_port      = 8000

}

resource "ibm_code_engine_app" "frontend" {
  name            = "frontend"
  project_id      = ibm_code_engine_project.dataclenz.project_id
  image_reference = var.frontend_image
  image_secret    = ibm_code_engine_secret.registry_secret.name
  image_port      = 3000
  depends_on = [ ibm_code_engine_app.backend ]
  run_env_variables {
    type  = "literal"
    name  = "REACT_APP_BACKEND_URL"
    value = ibm_code_engine_app.backend.endpoint
  }  
}
